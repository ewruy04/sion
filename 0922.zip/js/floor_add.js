/* ---------------------------
 * DOM refs
 * --------------------------- */
const fileInput     = document.getElementById('fileInput');
const img           = document.getElementById('img');
const svg           = document.getElementById('svg');
const stageInner    = document.getElementById('stageInner');
const floatConfirm  = document.getElementById('floatConfirm');
const confirmBtn    = document.getElementById('confirmBtn');
const cancelBtn     = document.getElementById('cancelBtn');
const snapHint      = document.getElementById('snapHint');

const naturalSizeEl = document.getElementById('naturalSize');
const ptCountEl     = document.getElementById('ptCount');
const lastPxEl      = document.getElementById('lastPx');
const lastPctEl     = document.getElementById('lastPct');

const undoBtn       = document.getElementById('undoBtn');
const clearPtsBtn   = document.getElementById('clearPtsBtn');
const clearAllBtn   = document.getElementById('clearAllBtn');

const regionNameInput = document.getElementById('regionName');
const saveRegionBtn   = document.getElementById('saveRegionBtn');

const jsonText       = document.getElementById('jsonText');
const copyJsonBtn    = document.getElementById('copyJsonBtn');
const downloadJsonBtn= document.getElementById('downloadJsonBtn');
const importJsonInput= document.getElementById('importJsonInput');
const regionList     = document.getElementById('regionList');

/* ---------------------------
 * 상태
 * --------------------------- */
let naturalW = 0, naturalH = 0;
let currentPts = [];  
let pending = null; 
let isClosed = false;
let regions  = [];

/* =========================================================
 * 중앙 배치 + 확대/축소
 * ========================================================= */
const contentLayer  = document.getElementById('contentLayer');
const zoomInBtn     = document.getElementById('zoomInBtn');
const zoomOutBtn    = document.getElementById('zoomOutBtn');
const zoomResetBtn  = document.getElementById('zoomResetBtn');

let zoom = 1;
const ZOOM_MIN  = 0.2;
const ZOOM_MAX  = 6;
const ZOOM_STEP = 0.1;

if (contentLayer) {
  contentLayer.style.transform = 'translate(-50%, -50%) scale(1)';
}

// SVG는 '원본 좌표계'만 유지
function setupSvgBox() {
  if (!img.src || !naturalW || !naturalH) return;
  svg.setAttribute('width',  naturalW);
  svg.setAttribute('height', naturalH);
  svg.setAttribute('viewBox', `0 0 ${naturalW} ${naturalH}`);
}

// 1:1 기준 중앙 배치 + 스케일만 적용
function applyZoomAndCenter() {
  if (!img.src || !naturalW || !naturalH) return;

  // contentLayer를 원본 px 크기로 고정
  contentLayer.style.width  = `${naturalW}px`;
  contentLayer.style.height = `${naturalH}px`;

  // 중앙 정렬 + 스케일(zoom)
  contentLayer.style.transform = `translate(-50%, -50%) scale(${zoom})`;

  // 이미지/오버레이는 원본 px, 부모 스케일을 그대로 탑승
  img.style.width  = `${naturalW}px`;
  img.style.height = `${naturalH}px`;

  setupSvgBox();
  renderAll();
}

function updateZoomLabel() {
  if (zoomResetBtn) zoomResetBtn.textContent = `${Math.round(zoom * 100)}%`;
}

function setZoom(next) {
  zoom = Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, next));
  applyZoomAndCenter();
  updateZoomLabel();
}

// 줌 버튼
zoomInBtn?.addEventListener('click',  () => setZoom(zoom + ZOOM_STEP));
zoomOutBtn?.addEventListener('click', () => setZoom(zoom - ZOOM_STEP));
zoomResetBtn?.addEventListener('click', () => setZoom(1));

// 창 크기 변화
let _rzTid = null;
window.addEventListener('resize', () => {
  clearTimeout(_rzTid);
  _rzTid = setTimeout(applyZoomAndCenter, 80);
});

/* ---------------------------
 * 초기화: 세션에서 이미지 받기
 * --------------------------- */
document.addEventListener('DOMContentLoaded', () => {
  // 표준 키(위에서 프리부트 스크립트가 맞춰줌) + 혹시 모를 직접 접근
  const dataURL =
    sessionStorage.getItem('lastFloorImage') ||
    sessionStorage.getItem('lastCroppedPNG') ||     // ← 추가
    sessionStorage.getItem('SION_DRAW_PNG');

  if (dataURL) {
    if (fileInput) fileInput.style.display = 'none';

    img.onload = () => {
      // 프리로드용 중앙 고정 클래스 제거(실제 크기/스케일 반영)
      img.classList.remove('preload-center');

      naturalW = img.naturalWidth;
      naturalH = img.naturalHeight;
      naturalSizeEl.textContent = `${naturalW} × ${naturalH}px`;
      setZoom(1); // 원본 1:1
      resetCurrent();
      renderAll();
      enableUi();
    };

    img.onerror = () => {
      alert('이미지를 불러오지 못했습니다.');
      if (fileInput) fileInput.style.display = '';
      enableUi();
    };

    // src 세팅 전에 한 번 중앙에 고정(점프 방지)
    contentLayer.style.transform = 'translate(-50%, -50%) scale(1)';
    img.src = dataURL;

    // 한 번 쓰고 지우기(원하면 유지해도 OK)
    sessionStorage.removeItem('lastFloorImage');
    sessionStorage.removeItem('SION_DRAW_PNG');
    // lastCroppedPNG 는 재진입시에도 쓰고 싶으면 지우지 말 것
    // sessionStorage.removeItem('lastCroppedPNG');
  } else {
    if (fileInput) fileInput.style.display = '';
    enableUi();
  }
});

/* ---------------------------
 * 이미지 업로드
 * --------------------------- */
if (fileInput) {
  fileInput.addEventListener('change', () => {
    const f = fileInput.files?.[0];
    if (!f) return;
    const url = URL.createObjectURL(f);
    img.onload = () => {
      naturalW = img.naturalWidth;
      naturalH = img.naturalHeight;
      naturalSizeEl.textContent = `${naturalW} × ${naturalH}px`;
      setZoom(1);
      resetCurrent(); renderAll(); enableUi();
    };
    img.onerror = () => {
      alert('이미지를 불러오지 못했습니다.');
      enableUi();
    };
    contentLayer.style.transform = 'translate(-50%, -50%) scale(1)';
    img.src = url;
  });
}

/* =========================================================
 * 클릭 → 임시점 생성 & 스냅 판단
 * ========================================================= */
img.addEventListener('click', (e) => {
  if (!img.src || isClosed) return;
  const { x, y } = visClickToOriginal(e);
  pending = { x, y, clientX: e.clientX, clientY: e.clientY, snap: willSnapToFirst(e) };
  showFloatConfirm(e.clientX, e.clientY, pending.snap);
  renderAll();
});

function visClickToOriginal(e) {
  const rect = img.getBoundingClientRect();         // 화면상 크기
  const xVis = e.clientX - rect.left;
  const yVis = e.clientY - rect.top;
  return {
    x: +(xVis * (naturalW / rect.width)).toFixed(2),
    y: +(yVis * (naturalH / rect.height)).toFixed(2),
  };
}

// 첫 점 근처 인지
function willSnapToFirst(e) {
  if (currentPts.length === 0) return false;
  const first = currentPts[0];
  const rect = img.getBoundingClientRect();
  const firstVisX = first.x / naturalW * rect.width + rect.left;
  const firstVisY = first.y / naturalH * rect.height + rect.top;
  const dx = e.clientX - firstVisX;
  const dy = e.clientY - firstVisY;
  const dist = Math.hypot(dx, dy);
  const SNAP_TOL_VIS_PX = 14; // 화면상 14px 이내면 스냅
  return dist <= SNAP_TOL_VIS_PX;
}

// 단축키: Enter=확정, Esc=취소
window.addEventListener('keydown', (e) => {
  if (!pending) return;
  if (e.key === 'Enter') { confirmPending(); }
  if (e.key === 'Escape') { cancelPending(); }
});

confirmBtn?.addEventListener('click', confirmPending);
cancelBtn?.addEventListener('click', cancelPending);

function confirmPending() {
  if (!pending) return;
  if (pending.snap && currentPts.length >= 2) {
    isClosed = true;
    pending = null;
    hideFloatConfirm();
    updateInfo();
    renderAll();
    enableUi();
    return;
  }
  const { x, y } = pending;
  const xpct = +((x / naturalW) * 100).toFixed(2);
  const ypct = +((y / naturalH) * 100).toFixed(2);
  currentPts.push({ x, y, xpct, ypct });
  pending = null;
  hideFloatConfirm();
  updateInfo();
  renderAll();
  enableUi();
}

function cancelPending() { pending = null; hideFloatConfirm(); renderAll(); }

function showFloatConfirm(clientX, clientY, snapped) {
  const rStage = stageInner.getBoundingClientRect();
  floatConfirm.style.left = (clientX - rStage.left) + 'px';
  floatConfirm.style.top  = (clientY - rStage.top)  + 'px';
  if (snapHint) snapHint.style.display = snapped ? 'inline' : 'none';
  floatConfirm.style.display = 'flex';
}
function hideFloatConfirm() { floatConfirm.style.display = 'none'; }

/* ---------------------------
 * 편집 버튼들
 * --------------------------- */
undoBtn?.addEventListener('click', () => {
  if (!currentPts.length || isClosed) return;
  currentPts.pop();
  updateInfo(); renderAll(); enableUi();
});
clearPtsBtn?.addEventListener('click', () => { resetCurrent(); renderAll(); enableUi(); });
clearAllBtn?.addEventListener('click', () => { regions = []; dumpJson(); renderAll(); enableUi(); });

function resetCurrent() {
  currentPts = []; pending = null; isClosed = false;
  hideFloatConfirm(); updateInfo();
}

/* ---------------------------
 * 구역 저장 (닫힘+이름)
 * --------------------------- */
saveRegionBtn?.addEventListener('click', () => {
  const name = regionNameInput.value.trim();
  if (!name) { alert('エリア名を入力してください。'); return; }
  if (!isClosed || currentPts.length < 3) { alert('구역을 스냅으로 닫아 주세요(최소 3점).'); return; }
  regions.push({ name, points: currentPts.map(p => ({ ...p })) });
  regionNameInput.value = '';
  resetCurrent();
  dumpJson(); renderAll(); enableUi();
});

function regionsToJson() {
  try { return JSON.stringify(regions ?? [], null, 2); }
  catch { return '[]'; }
}

/* ---------------------------
 * JSON IO (완료 버튼)
 * --------------------------- */
downloadJsonBtn?.addEventListener('click', () => {
  const data = regionsToJson();
  const blob = new Blob([data], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'regions.json';
  a.click();
  URL.revokeObjectURL(a.href);
  window.location.reload();
});

/* ---------------------------
 * 렌더링
 * --------------------------- */
function renderAll() {
  while (svg.firstChild) svg.removeChild(svg.firstChild);

  // 저장된 폴리곤
  regions.forEach(r => {
    if (r.points.length >= 3) {
      const ptsStr = r.points.map(p => `${p.x},${p.y}`).join(' ');
      const poly = mk('polygon', { points: ptsStr, class: 'poly' });
      svg.appendChild(poly);
      const label = mk('text', {
        x: r.points[0].x + 6,
        y: r.points[0].y - 6,
        fill: 'rgba(0,0,0,0.85)',
        'font-size': 14
      });
      label.textContent = r.name;
      svg.appendChild(label);
    }
  });

  // 현재 그리는 도형
  if (currentPts.length) {
    if (isClosed && currentPts.length >= 3) {
      const ptsStr = currentPts.map(p => `${p.x},${p.y}`).join(' ');
      svg.appendChild(mk('polygon', { points: ptsStr, class: 'poly' }));
    } else {
      const d = currentPts.map(p => `${p.x},${p.y}`).join(' ');
      svg.appendChild(mk('polyline', { points: d, class: 'wire' }));
      if (pending && currentPts.length) {
        const last = currentPts[currentPts.length - 1];
        const c = mk('polyline', {
          points: `${last.x},${last.y} ${pending.x},${pending.y}`,
          class: `wire ${pending.snap ? 'wire-snap' : ''}`
        });
        svg.appendChild(c);
      }
    }
    // 점들
    currentPts.forEach((p, i) => {
      svg.appendChild(mk('circle', { cx: p.x, cy: p.y, r: 6, class: `pt ${i === 0 ? 'pt-first' : ''}` }));
      const t = mk('text', { x: p.x + 8, y: p.y - 8, fill: 'rgba(0,0,0,0.85)', 'font-size': 12 });
      t.textContent = i + 1; svg.appendChild(t);
    });
    // 스냅 표시
    if (pending && pending.snap && currentPts.length) {
      const f = currentPts[0];
      const ringR = 14 * (naturalW / img.getBoundingClientRect().width);
      svg.appendChild(mk('circle', { cx: f.x, cy: f.y, r: ringR, class: 'snap-halo' }));
      svg.appendChild(mk('circle', { cx: pending.x, cy: pending.y, r: 6, class: 'pt-pending' }));
    } else if (pending) {
      svg.appendChild(mk('circle', { cx: pending.x, cy: pending.y, r: 6, class: 'pt-pending' }));
    }
  }
  renderRegionList();
}

function mk(tag, attrs) {
  const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
  Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, v));
  return el;
}

function updateInfo() {
  const n = currentPts.length; ptCountEl.textContent = n;
  if (n) {
    const p = currentPts[n - 1];
    lastPxEl.textContent = `x:${p.x}, y:${p.y}`;
    const xp = p.xpct ?? ((p.x / naturalW * 100).toFixed(2));
    const yp = p.ypct ?? ((p.y / naturalH * 100).toFixed(2));
    lastPctEl.textContent = `x:${xp}%, y:${yp}%`;
  } else {
    lastPxEl.textContent = '-'; lastPctEl.textContent = '-';
  }
}

function dumpJson() { if (!jsonText) return; jsonText.value = regionsToJson(); }

function enableUi() {
  const hasImg = !!img.src;
  const hasPts = currentPts.length > 0;
  const hasRegions = regions.length > 0;
  const canSave = hasImg && isClosed && currentPts.length >= 3 && regionNameInput.value.trim().length > 0;

  if (undoBtn) undoBtn.disabled = !hasPts || isClosed;
  if (clearPtsBtn) clearPtsBtn.disabled = !hasPts && !isClosed;
  if (clearAllBtn) clearAllBtn.disabled = !hasRegions;
  if (saveRegionBtn) saveRegionBtn.disabled = !canSave;
  if (downloadJsonBtn) downloadJsonBtn.disabled = !hasRegions;

  dumpJson();
}

regionNameInput?.addEventListener('input', enableUi);

/* ---------------------------
 * 리스트 렌더링
 * --------------------------- */
function renderRegionList() {
  regionList.innerHTML = '';
  regions.forEach((r, idx) => {
    const div = document.createElement('div'); div.className = 'item mono';
    const ptsPreview = r.points.slice(0, 3).map(p => `(${p.x},${p.y})`).join(', ') + (r.points.length > 3 ? ' ...' : '');
    div.innerHTML = `
      <div><b>${idx + 1}. ${escapeHtml(r.name)}</b> <span class="muted">/ ${r.points.length} pts</span></div>
      <div class="muted">${escapeHtml(ptsPreview)}</div>
      <div class="row" style="margin-top:6px;">
        <button data-act="delete" data-idx="${idx}">削除</button>
      </div>`;
    regionList.appendChild(div);
  });
  regionList.querySelectorAll('button').forEach(b => {
    const idx = +b.dataset.idx, act = b.dataset.act;
    b.addEventListener('click', () => {
      if (act === 'delete') { regions.splice(idx, 1); dumpJson(); renderAll(); enableUi(); }
    });
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[m]));
}
