let idx = 1;
const total = 3;
const PREV_URL = "building_add.html"
const NEXT_URL = "floor_add.html";

window.onload = function() {
  updateUI();
};

function updateUI() {
    // 左
    if (idx === 1) {
        document.getElementById("arrowPre").classList.add("hidden");
        document.getElementById("backBtn").classList.remove("hidden");
    } else {
        document.getElementById("arrowPre").classList.remove("hidden");
        document.getElementById("backBtn").classList.add("hidden");
    }

    // 右
    if (idx === total) {
        document.getElementById("arrowNext").classList.add("hidden");
        document.getElementById("doneBtn").classList.remove("hidden");
    } else {
        document.getElementById("arrowNext").classList.remove("hidden");
        document.getElementById("doneBtn").classList.add("hidden");
    }
}

//->
function nextScreen() {
    if (idx < total) {
        document.getElementById("screen" + idx).classList.remove("show");
        idx++;
        document.getElementById("screen" + idx).classList.add("show");
        updateUI();
    }
}

//<-
function preScreen() {
    if (idx > 1) {
        document.getElementById("screen" + idx).classList.remove("show");
        idx--;
        document.getElementById("screen" + idx).classList.add("show");
        updateUI();
    }
}

function goBack(){
  window.location.href = PREV_URL;
}
function goNextPage(){
  window.location.href = NEXT_URL;
}


