(() => {
  /* =========================================================
   * [세션 0] 기본 레퍼런스
   *  - 링(ring)·타입 분별 입력 의존 로직 삭제
   *  - 내부적으로는 도형을 화면 그리기/연산용으로만 사용
   *  - 저장 시에는 오직 좌표 배열(coords)만 내보냄
   * =======================================================*/
  const canvas = document.getElementById('canvas');
  const ctx = canvas.getContext('2d');
  const statusEl = document.getElementById('status');

  const toolrail = document.querySelector('.toolrail');
  const btnGroup = document.getElementById('btnGroup');
  const btnUngroup = document.getElementById('btnUngroup');
  const btnDelete = document.getElementById('btnDelete');
  const chkSnap = document.getElementById('chkSnap');
  const gridSizeInput = document.getElementById('gridSize');
  const btnSaveJSON = document.getElementById('btnSaveJSON');

  // polygon-clipping (합집합 외곽선 추출용) — 내부 계산에만 사용
  let pcLib = null;
  async function ensurePc() {
    if (pcLib) return pcLib;
    if (window.polygonClipping) { pcLib = window.polygonClipping; return pcLib; }
    try {
      const mod = await import('https://esm.run/polygon-clipping@0.15.3');
      pcLib = mod && (mod.default || mod);
    } catch (e) {
      console.error('polygon-clipping ロード失敗:', e);
      pcLib = null;
    }
    return pcLib;
  }

  toolrail?.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-tool]');
    if (!btn || !toolrail.contains(btn)) return;
    setTool(btn.dataset.tool);
    document.querySelectorAll('.toolrail .iconbtn[data-tool]').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  });

  const state = {
    tool: 'select',
    objects: [],
    selection: new Set(),
    maybeDragging: false,
    dragging: false,
    dragStart: { x: 0, y: 0 },

    // 리사이즈/회전
    resizing: false,
    rotating: false,
    activeHandle: null,
    resizeTargetId: null,
    resizeStartMouse: { x: 0, y: 0 },
    resizeStartBBox: null,
    resizeRefPoints: null,
    rotateTargetId: null,
    rotateStartMouse: { x: 0, y: 0 },
    rotateStartAngle: 0,
    rotateAnchor: null,

    groupResizeSnapshot: null,
    groupRotateSnapshot: null,

    creating: null,

    lastMouse: { x: 0, y: 0 },
    gridSize: 10,
    snap: false,
    keymods: { shift: false, alt: false },
    resizeStartThick: { tV: null, tH: null },
    tracing: false,
    tracePoints: [],
  };

  const HANDLE_SIZE = 12;
  const ROTATE_HANDLE_OFFSET = 22;
  const HIT_PAD = 8;
  const DRAG_START_THRESHOLD = 6;
  const GROUP_HIDE_INNER_STROKES = true;

  const THICK_SENS = 0.35;
  const THICK_STEP = 2;
  const THICK_FINE = 0.4;
  const THICK_COARSE = 1.8;
  function roundTo(v, step) { return Math.round(v / step) * step; }

  let _id = 1;
  const genId = () => `id_${_id++}`;
  function rad2deg(r) { return r * 180 / Math.PI; }
  function snap(v) { return state.snap ? Math.round(v / state.gridSize) * state.gridSize : v; }
  function pointInRect(px, py, x, y, w, h) { return px >= x && px <= x + w && py >= y && py <= y + h; }
  function rotatePoint(px, py, cx, cy, ang) {
    const s = Math.sin(ang), c = Math.cos(ang);
    const dx = px - cx, dy = py - cy;
    return { x: cx + dx * c - dy * s, y: cy + dx * s + dy * c };
  }
  function invRotatePoint(px, py, cx, cy, ang) { return rotatePoint(px, py, cx, cy, -ang); }
  function groupCenter(g) { const b = g.bbox(); return { cx: b.x + b.w / 2, cy: b.y + b.h / 2 }; }

  const SHAPE_TOOLS = new Set(['rect', 'tri', 'circle', 'lshape', 'cshape', 'line']);
  function setActiveToolButton(t) {
    document.querySelectorAll('.toolrail [data-tool]').forEach(b => {
      b.classList.toggle('active', b.dataset.tool === t);
    });
  }

  /* =========================================================
   * [세션 1] 도형 클래스 — 화면 그리기/히트 전용
   *   (저장은 최종 외곽선 좌표만 사용)
   * =======================================================*/
  class Shape {
    constructor(type, opts = {}) {
      this.kind = 'shape';
      this.id = genId();
      this.type = type;
      this.x = opts.x ?? 100;
      this.y = opts.y ?? 100;
      this.w = opts.w ?? 120;
      this.h = opts.h ?? 80;
      this.fill = opts.fill ?? '#f5f9ffff';
      this.stroke = opts.stroke ?? '#222';
      this.lineWidth = opts.lineWidth ?? 2;
      this.meta = opts.meta || {};
      this.angle = opts.angle ?? 0;
    }
    get cx() { return this.x + this.w / 2; }
    get cy() { return this.y + this.h / 2; }
    bbox() { return { x: this.x, y: this.y, w: this.w, h: this.h }; }
    moveBy(dx, dy) { this.x += dx; this.y += dy; }

    drawSelectedOutline() {
      const corners = [
        { x: this.x, y: this.y },
        { x: this.x + this.w, y: this.y },
        { x: this.x + this.w, y: this.y + this.h },
        { x: this.x, y: this.y + this.h },
      ].map(p => rotatePoint(p.x, p.y, this.cx, this.cy, this.angle));
      ctx.save();
      ctx.setLineDash([4, 3]);
      ctx.lineWidth = 1;
      ctx.strokeStyle = '#00bcd4';
      ctx.beginPath();
      ctx.moveTo(corners[0].x, corners[0].y);
      for (let i = 1; i < corners.length; i++) ctx.lineTo(corners[i].x, corners[i].y);
      ctx.closePath(); ctx.stroke();
      ctx.restore();
      drawHandles(this);
    }

    _withRotation(c, drawBody) { c.save(); c.translate(this.cx, this.cy); c.rotate(this.angle); drawBody(); c.restore(); }

    toJSON() { return { id: this.id, type: this.type, x: this.x, y: this.y, w: this.w, h: this.h }; }
  }

  class Rect extends Shape {
    constructor(opts) { super('rect', opts); }
    draw() {
      this._withRotation(ctx, () => {
        ctx.fillStyle = this.fill;
        ctx.fillRect(-this.w / 2, -this.h / 2, this.w, this.h);
        ctx.lineWidth = this.lineWidth;
        ctx.strokeStyle = this.stroke;
        ctx.strokeRect(-this.w / 2, -this.h / 2, this.w, this.h);
      });
    }
    hit(px, py) {
      const p = invRotatePoint(px, py, this.cx, this.cy, this.angle);
      return pointInRect(p.x, p.y, this.x, this.y, this.w, this.h);
    }
  }

  class Tri extends Shape {
    constructor(opts) { super('tri', opts); }
    pathLocal() {
      const w = this.w, h = this.h;
      const p = new Path2D();
      p.moveTo(0, -h / 2);
      p.lineTo(w / 2, h / 2);
      p.lineTo(-w / 2, h / 2);
      p.closePath();
      return p;
    }
    draw() {
      this._withRotation(ctx, () => {
        const p = this.pathLocal();
        ctx.fillStyle = this.fill;
        ctx.fill(p);
        ctx.lineWidth = this.lineWidth;
        ctx.strokeStyle = this.stroke;
        ctx.stroke(p);
      });
    }
    hit(px, py) {
      const lp = invRotatePoint(px, py, this.cx, this.cy, this.angle);
      const p = this.pathLocal();
      return ctx.isPointInPath(p, lp.x - this.cx, lp.y - this.cy);
    }
  }

  class Circle extends Shape {
    constructor(opts) { super('circle', opts); }
    draw() {
      this._withRotation(ctx, () => {
        const rx = this.w / 2, ry = this.h / 2;
        ctx.beginPath();
        ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
        ctx.fillStyle = this.fill;
        ctx.fill();
        ctx.lineWidth = this.lineWidth;
        ctx.strokeStyle = this.stroke;
        ctx.stroke();
      });
    }
    hit(px, py) {
      const p = invRotatePoint(px, py, this.cx, this.cy, this.angle);
      const rx = Math.max(this.w / 2, 1e-6);
      const ry = Math.max(this.h / 2, 1e-6);
      const nx = (p.x - this.cx) / rx;
      const ny = (p.y - this.cy) / ry;
      return nx * nx + ny * ny <= 1;
    }
  }

  class LShape extends Shape {
    constructor(opts) {
      super('lshape', opts);
      const base = Math.min(this.w, this.h);
      this.tH = opts?.tH ?? base * 0.4;
      this.tV = opts?.tV ?? base * 0.4;
    }
    pathLocal() {
      const w = this.w, h = this.h, tH = this.tH, tV = this.tV;
      const p = new Path2D();
      p.moveTo(-w / 2, -h / 2);
      p.lineTo(w / 2, -h / 2);
      p.lineTo(w / 2, -h / 2 + tH);
      p.lineTo(-w / 2 + tV, -h / 2 + tH);
      p.lineTo(-w / 2 + tV, h / 2);
      p.lineTo(-w / 2, h / 2);
      p.closePath();
      return p;
    }
    draw() {
      this._withRotation(ctx, () => { const p = this.pathLocal(); ctx.fillStyle = this.fill; ctx.fill(p); ctx.lineWidth = this.lineWidth; ctx.strokeStyle = this.stroke; ctx.stroke(p); });
    }
    hit(px, py) {
      const lp = invRotatePoint(px, py, this.cx, this.cy, this.angle);
      const p = this.pathLocal();
      return ctx.isPointInPath(p, lp.x - this.cx, lp.y - this.cy);
    }
    toJSON() { const j = super.toJSON(); j.tH = this.tH; j.tV = this.tV; return j; }
  }

  class CShape extends Shape {
    constructor(opts) {
      super('cshape', opts);
      const base = Math.min(this.w, this.h);
      this.tH = opts?.tH ?? base * 0.3;
      this.tV = opts?.tV ?? base * 0.3;
    }
    pathLocal() {
      const w = this.w, h = this.h, tH = this.tH, tV = this.tV;
      const p = new Path2D();
      p.moveTo(-w / 2, -h / 2);
      p.lineTo(w / 2, -h / 2);
      p.lineTo(w / 2, -h / 2 + tH);
      p.lineTo(-w / 2 + tV, -h / 2 + tH);
      p.lineTo(-w / 2 + tV, h / 2 - tH);
      p.lineTo(w / 2, h / 2 - tH);
      p.lineTo(w / 2, h / 2);
      p.lineTo(-w / 2, h / 2);
      p.closePath();
      return p;
    }
    draw() {
      this._withRotation(ctx, () => { const p = this.pathLocal(); ctx.fillStyle = this.fill; ctx.fill(p); ctx.lineWidth = this.lineWidth; ctx.strokeStyle = this.stroke; ctx.stroke(p); });
    }
    hit(px, py) {
      const lp = invRotatePoint(px, py, this.cx, this.cy, this.angle);
      const p = this.pathLocal();
      return ctx.isPointInPath(p, lp.x - this.cx, lp.y - this.cy);
    }
    toJSON() { const j = super.toJSON(); j.tH = this.tH; j.tV = this.tV; return j; }
  }

  class LinePen extends Shape { constructor(opts) { super('line', opts); } draw(){} hit(){ return false; } }

  class Poly extends Shape {
    constructor(points, opts) {
      super('poly', opts);
      this.meta.points = points.map(p => ({ x: p.x, y: p.y }));
      const xs = points.map(p => p.x), ys = points.map(p => p.y);
      this.x = Math.min(...xs); this.y = Math.min(...ys);
      this.w = Math.max(...xs) - this.x; this.h = Math.max(...ys) - this.y;
      this.angle = 0;
    }
    moveBy(dx, dy) {
      this.x += dx; this.y += dy;
      this.meta.points = this.meta.points.map(p => ({ x: p.x + dx, y: p.y + dy }));
    }
    pathWorld() {
      const pth = new Path2D();
      const pts = this.meta.points;
      if (!pts.length) return pth;
      pth.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length; i++) pth.lineTo(pts[i].x, pts[i].y);
      pth.closePath();
      return pth;
    }
    draw() {
      const p = this.pathWorld();
      ctx.save();
      ctx.fillStyle = this.fill;
      ctx.fill(p);
      ctx.lineWidth = this.lineWidth;
      ctx.strokeStyle = this.stroke;
      ctx.stroke(p);
      ctx.restore();
    }
    hit(px, py) { return ctx.isPointInPath(this.pathWorld(), px, py); }
    toJSON() { const j = super.toJSON(); j.meta = { points: this.meta.points }; return j; }
  }

  /* =========================================================
   * [세션 2] 그룹 & 공용 렌더
   * =======================================================*/
  class Group {
    constructor(children) { this.id = genId(); this.kind = 'group'; this.children = children; }
    bbox() {
      const boxes = this.children.map(id => getObj(id).bbox());
      const x = Math.min(...boxes.map(b => b.x));
      const y = Math.min(...boxes.map(b => b.y));
      const r = Math.max(...boxes.map(b => b.x + b.w));
      const b = Math.max(...boxes.map(b => b.y + b.h));
      return { x, y, w: r - x, h: b - y };
    }
    moveBy(dx, dy) { this.children.forEach(id => getObj(id).moveBy(dx, dy)); }
    drawSelectedOutline() {
      const { x, y, w, h } = this.bbox();
      ctx.save(); ctx.setLineDash([6, 3]); ctx.lineWidth = 1.2; ctx.strokeStyle = '#10b981'; ctx.strokeRect(x, y, w, h); ctx.restore();
      drawHandles(this);
    }
    toJSON() { return { kind: 'group', id: this.id, children: this.children }; }
  }
  function getObj(id) { return state.objects.find(o => o && o.id === id); }
  function withRotationOn(c, obj, fn) { c.save(); c.translate(obj.cx, obj.cy); c.rotate(obj.angle); fn(); c.restore(); }

  function fillShapeOn(c, o) {
    c.save(); c.fillStyle = o.fill;
    if (o.type === 'rect') withRotationOn(c, o, () => c.fillRect(-o.w / 2, -o.h / 2, o.w, o.h));
    else if (o.type === 'tri') withRotationOn(c, o, () => { const p = o.pathLocal(); c.fill(p); });
    else if (o.type === 'circle') withRotationOn(c, o, () => { c.beginPath(); c.ellipse(0,0,o.w/2,o.h/2,0,0,Math.PI*2); c.fill(); });
    else if (o.type === 'lshape' || o.type === 'cshape') withRotationOn(c, o, () => { const p = o.pathLocal(); c.fill(p); });
    else if (o.type === 'poly') { const p = o.pathWorld(); c.fill(p); }
    c.restore();
  }
  function strokeShapeOn(c, o) {
    c.save(); c.lineWidth = o.lineWidth; c.strokeStyle = o.stroke;
    if (o.type === 'rect') withRotationOn(c, o, () => c.strokeRect(-o.w / 2, -o.h / 2, o.w, o.h));
    else if (o.type === 'tri') withRotationOn(c, o, () => { const p = o.pathLocal(); c.stroke(p); });
    else if (o.type === 'circle') withRotationOn(c, o, () => { c.beginPath(); c.ellipse(0,0,o.w/2,o.h/2,0,0,Math.PI*2); c.stroke(); });
    else if (o.type === 'lshape' || o.type === 'cshape') withRotationOn(c, o, () => { const p = o.pathLocal(); c.stroke(p); });
    else if (o.type === 'poly') { const p = o.pathWorld(); c.stroke(p); }
    c.restore();
  }

  /* =========================================================
   * [세션 3] 내보내기/저장 도우미 (좌표만 저장)
   * =======================================================*/
// === 멀티폴리곤 bbox 계산: 모든 outer ring 좌표에서 min/max ===
function bboxFromMultiPolygon(mp) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const poly of mp) {
    const outer = poly?.[0]; if (!outer) continue;
    for (const [x, y] of outer) {
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
    }
  }
  if (!isFinite(minX) || !isFinite(minY) || !isFinite(maxX) || !isFinite(maxY)) return null;
  return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
}

// === 단일 객체를 주어진 컨텍스트에 그리기 (그룹이면 합집합 외곽선만 남기기 로직 유지) ===
function renderSingleObjectOn(ctx2, obj) {
  if (obj.kind === 'group') {
    const children = obj.children.map(id => getObj(id)).filter(Boolean);
    // 채우기 먼저
    children.forEach(ch => fillShapeOn(ctx2, ch));

    if (!pcLib) {
      // 라이브러리 없으면 내부선 보이고 끝
      children.forEach(ch => strokeShapeOn(ctx2, ch));
      return;
    }

    // 내부선 제거용 오프스크린
    const off = document.createElement('canvas');
    off.width = canvas.width;
    off.height = canvas.height;
    const octx = off.getContext('2d');
    children.forEach(ch => strokeShapeOn(octx, ch));

    // 그룹 합집합 외곽선 안의 선 지우기
    const multi = groupToPolygons(obj, pcLib);
    octx.save();
    octx.globalCompositeOperation = 'destination-out';
    octx.fillStyle = '#000';
    octx.beginPath();
    multi.forEach(poly => {
      const outer = poly[0]; if (!outer || !outer.length) return;
      octx.moveTo(outer[0][0], outer[0][1]);
      for (let i = 1; i < outer.length; i++) octx.lineTo(outer[i][0], outer[i][1]);
      octx.closePath();
    });
    octx.fill();
    octx.restore();

    ctx2.drawImage(off, 0, 0);

    // 최외곽선만 다시 그리기
    const outlineColor = children[0]?.stroke ?? '#222';
    const outlineWidth = Math.max(2, children[0]?.lineWidth ?? 2);
    const multi2 = groupToPolygons(obj, pcLib);
    drawMultiPolygonStrokeOn(ctx2, multi2, outlineColor, outlineWidth);
    return;
  }

  // 개별 도형
  fillShapeOn(ctx2, obj);
  strokeShapeOn(ctx2, obj);
}

// === [핵심] 객체 외곽선 기준 타이트 크롭 PNG 저장 ===
async function exportCroppedPNGOfObject(obj, filename = 'shape.png', padding = 6) {
  await ensurePc();

  // 1) 외곽선 멀티폴리곤 얻기
  let mp = null;
  if (obj.kind === 'group') {
    mp = pcLib ? groupToPolygons(obj, pcLib) : null;
  } else {
    mp = shapeToPolygon(obj);
  }

  // 2) 바운딩박스 계산 (라이브러리 실패 시 폴백: 월드 BBox)
  let bbox = (mp && mp[0] && mp[0][0]) ? bboxFromMultiPolygon(mp) : worldBBoxOfShape(obj);
  if (!bbox) return;

  // 살짝 패딩 추가(스트로크 안 잘리게)
  const pad = Math.max(0, padding|0);
  const w = Math.ceil(bbox.w + pad * 2);
  const h = Math.ceil(bbox.h + pad * 2);

  // 3) 오프스크린에 투명 배경으로 타이트 렌더
  const off = document.createElement('canvas');
  off.width = Math.max(1, w);
  off.height = Math.max(1, h);
  const octx = off.getContext('2d');

  // 바운딩의 좌상단을 (pad, pad)로 오도록 이동
  octx.save();
  octx.translate(-bbox.x + pad, -bbox.y + pad);
  renderSingleObjectOn(octx, obj);
  octx.restore();

  // 4) 다운로드 + 세션 저장
  const url = off.toDataURL('image/png');
  downloadDataURL(filename, url);
  sessionStorage.setItem('lastCroppedPNG', url);
}

  
  function downloadDataURL(filename, dataURL) {
    const a = document.createElement('a');
    a.href = dataURL; a.download = filename;
    document.body.appendChild(a); a.click();
    setTimeout(() => { a.remove(); }, 0);
  }

  function renderExportOn(targetCtx) {
    const groupedIds = new Set();
    state.objects.forEach(o => { if (o && o.kind === 'group') o.children.forEach(id => groupedIds.add(id)); });
    targetCtx.clearRect(0, 0, canvas.width, canvas.height);

    for (const obj of state.objects) {
      if (!obj || obj.kind === 'group') continue;
      if (!groupedIds.has(obj.id)) { fillShapeOn(targetCtx, obj); strokeShapeOn(targetCtx, obj); }
    }

    const lib = pcLib;
    for (const obj of state.objects) {
      if (!obj || obj.kind !== 'group') continue;

      if (!lib) {
        obj.children.map(getObj).filter(Boolean).forEach(o => { fillShapeOn(targetCtx, o); strokeShapeOn(targetCtx, o); });
        continue;
      }
      const children = obj.children.map(getObj).filter(Boolean);
      children.forEach(o => fillShapeOn(targetCtx, o));
      const multi = groupToPolygons(obj, lib);
      const outlineColor = children[0]?.stroke ?? '#222';
      const outlineWidth = Math.max(2, children[0]?.lineWidth ?? 2);
      drawMultiPolygonStrokeOn(targetCtx, multi, outlineColor, outlineWidth);
    }
  }

  function worldBBoxOfShape(o) {
    if (o.type === 'poly') {
      const pts = (o.meta.points || []);
      const xs = pts.map(p => p.x), ys = pts.map(p => p.y);
      return { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) };
    }
    const cx = o.x + o.w / 2, cy = o.y + o.h / 2, ang = o.angle || 0;
    const corners = [
      { x: o.x, y: o.y }, { x: o.x + o.w, y: o.y }, { x: o.x + o.w, y: o.y + o.h }, { x: o.x, y: o.y + o.h },
    ].map(p => rotatePoint(p.x, p.y, cx, cy, ang));
    const xs = corners.map(p => p.x), ys = corners.map(p => p.y);
    return { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) };
  }
  function worldBBoxOfTopLevel(topLevel) {
    const boxes = [];
    for (const o of topLevel) {
      if (o.kind === 'group') o.children.map(id => getObj(id)).filter(Boolean).forEach(ch => boxes.push(worldBBoxOfShape(ch)));
      else boxes.push(worldBBoxOfShape(o));
    }
    if (!boxes.length) return null;
    const x1 = Math.min(...boxes.map(b => b.x));
    const y1 = Math.min(...boxes.map(b => b.y));
    const x2 = Math.max(...boxes.map(b => b.x + b.w));
    const y2 = Math.max(...boxes.map(b => b.y + b.h));
    return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
  }
  function renderTopLevelOn(ctx2, topLevel) {
    for (const o of topLevel) {
      if (o.kind === 'group') {
        const children = o.children.map(id => getObj(id)).filter(Boolean);
        children.forEach(ch => { fillShapeOn(ctx2, ch); });
        if (pcLib) {
          const multi = groupToPolygons(o, pcLib);
          const outlineColor = children[0]?.stroke ?? '#222';
          const outlineWidth = Math.max(2, children[0]?.lineWidth ?? 2);
          drawMultiPolygonStrokeOn(ctx2, multi, outlineColor, outlineWidth);
        } else {
          children.forEach(ch => { strokeShapeOn(ctx2, ch); });
        }
      } else {
        fillShapeOn(ctx2, o); strokeShapeOn(ctx2, o);
      }
    }
  }

  function exportPNG(filename = 'floor.png') {
    const off = document.createElement('canvas');
    off.width = canvas.width; off.height = canvas.height;
    const octx = off.getContext('2d');
    renderExportOn(octx);
    const url = off.toDataURL('image/png');
    downloadDataURL(filename, url);

    const buildingId = sessionStorage.getItem('currentBuildingId') || 'B001';
    sessionStorage.setItem(`bld:${buildingId}:sectionImage`, url);
    sessionStorage.setItem('lastFloorImage', url);
  }

  /* =========================================================
   * [세션 4] 화면 렌더 루프
   * =======================================================*/
  function drawGrid() {
    const g = state.gridSize;
    ctx.save(); ctx.lineWidth = 0.5; ctx.strokeStyle = '#eee';
    for (let x = 0; x < canvas.width; x += g) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke(); }
    for (let y = 0; y < canvas.height; y += g) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke(); }
    ctx.restore();
  }
  function drawMultiPolygonStrokeOn(c, multi, color = '#222', width = 2) {
    c.save(); c.setLineDash([]); c.strokeStyle = color; c.lineWidth = width;
    for (const polygon of multi) {
      const outer = polygon[0]; if (!outer || outer.length === 0) continue;
      c.beginPath(); c.moveTo(outer[0][0], outer[0][1]);
      for (let i = 1; i < outer.length; i++) c.lineTo(outer[i][0], outer[i][1]);
      c.closePath(); c.stroke();
    }
    c.restore();
  }
  function renderGroup(g) {
    const children = g.children.map(id => getObj(id)).filter(Boolean);
    children.forEach(o => fillShapeOn(ctx, o));
    if (!GROUP_HIDE_INNER_STROKES) { children.forEach(o => strokeShapeOn(ctx, o)); return; }

    const off = document.createElement('canvas');
    off.width = canvas.width; off.height = canvas.height;
    const octx = off.getContext('2d');
    children.forEach(o => strokeShapeOn(octx, o));

    if (!pcLib) { ctx.drawImage(off, 0, 0); return; }
    const multi = groupToPolygons(g, pcLib);
    octx.save(); octx.globalCompositeOperation = 'destination-out'; octx.fillStyle = '#000';
    // 합집합 채우기 후 내부 스트로크 제거
    octx.beginPath();
    multi.forEach(poly => {
      const outer = poly[0]; if (!outer || !outer.length) return;
      octx.moveTo(outer[0][0], outer[0][1]);
      for (let i = 1; i < outer.length; i++) octx.lineTo(outer[i][0], outer[i][1]);
      octx.closePath();
    });
    octx.fill(); octx.restore();

    ctx.drawImage(off, 0, 0);
    const outlineColor = children[0]?.stroke ?? '#222';
    const outlineWidth = Math.max(2, children[0]?.lineWidth ?? 2);
    drawMultiPolygonStrokeOn(ctx, multi, outlineColor, outlineWidth);
  }

  function render() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawGrid();

    const groupedIds = new Set();
    state.objects.forEach(o => { if (o && o.kind === 'group') o.children.forEach(id => groupedIds.add(id)); });

    for (const obj of state.objects) {
      if (!obj || obj.kind === 'group') continue;
      if (!groupedIds.has(obj.id)) obj.draw();
    }
    for (const obj of state.objects) { if (obj && obj.kind === 'group') renderGroup(obj); }

    for (const id of state.selection) { const obj = getObj(id); if (obj) obj.drawSelectedOutline(); }

    if (state.tool === 'line' && state.tracing && state.tracePoints.length > 0) {
      ctx.save();
      ctx.lineWidth = 2; ctx.strokeStyle = '#ff9800';
      const pts = state.tracePoints;
      ctx.beginPath(); ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y);
      ctx.stroke();
      ctx.fillStyle = '#ff9800';
      pts.forEach(p => { ctx.beginPath(); ctx.arc(p.x, p.y, 3, 0, Math.PI * 2); ctx.fill(); });
      const f = pts[0]; ctx.beginPath(); ctx.arc(f.x, f.y, 10, 0, Math.PI * 2); ctx.stroke();
      ctx.restore();
    }

    if (state.creating) {
      const { type, start, end } = state.creating;
      const x1 = Math.min(start.x, end.x), y1 = Math.min(start.y, end.y);
      const x2 = Math.max(start.x, end.x), y2 = Math.max(start.y, end.y);
      const w = x2 - x1, h = y2 - y1;

      ctx.save(); ctx.lineWidth = 2; ctx.setLineDash([6, 4]); ctx.strokeStyle = '#2563eb';
      if (type === 'rect') { ctx.strokeRect(x1, y1, w, h); }
      else if (type === 'tri') {
        ctx.beginPath(); ctx.moveTo(x1 + w / 2, y1); ctx.lineTo(x2, y2); ctx.lineTo(x1, y2); ctx.closePath(); ctx.stroke();
      }
      else if (type === 'circle') {
        ctx.beginPath(); ctx.ellipse(x1 + w / 2, y1 + h / 2, Math.abs(w / 2), Math.abs(h / 2), 0, 0, Math.PI * 2); ctx.stroke();
      }
      else if (type === 'lshape') {
        const tH = Math.min(w, h) * 0.4, tV = Math.min(w, h) * 0.4;
        ctx.beginPath();
        ctx.moveTo(x1, y1); ctx.lineTo(x2, y1); ctx.lineTo(x2, y1 + tH);
        ctx.lineTo(x1 + tV, y1 + tH); ctx.lineTo(x1 + tV, y2); ctx.lineTo(x1, y2);
        ctx.closePath(); ctx.stroke();
      }
      else if (type === 'cshape') {
        const tH = Math.min(w, h) * 0.3, tV = Math.min(w, h) * 0.3;
        ctx.beginPath();
        ctx.moveTo(x1, y1); ctx.lineTo(x2, y1); ctx.lineTo(x2, y1 + tH);
        ctx.lineTo(x1 + tV, y1 + tH); ctx.lineTo(x1 + tV, y2 - tH);
        ctx.lineTo(x2, y2 - tH); ctx.lineTo(x2, y2); ctx.lineTo(x1, y2);
        ctx.closePath(); ctx.stroke();
      }
      ctx.restore();
    }
  }

  /* =========================================================
   * [세션 5] 핸들/히트 테스트/커서
   * =======================================================*/
  function getHandles(obj) {
    if (obj.kind === 'group') {
      const { x, y, w, h } = obj.bbox();
      const corners = [{ x, y }, { x: x + w, y }, { x: x + w, y: y + h }, { x, y: y + h }];
      const [nw, ne, se, sw] = corners;
      const mid = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
      const n = mid(nw, ne), e = mid(ne, se), s = mid(se, sw), wpt = mid(sw, nw);
      const rx = n.x, ry = n.y - ROTATE_HANDLE_OFFSET;
      return [
        { x: nw.x, y: nw.y, code: 'nw', cursor: 'nwse-resize' },
        { x: n.x, y: n.y, code: 'n', cursor: 'ns-resize' },
        { x: ne.x, y: ne.y, code: 'ne', cursor: 'nesw-resize' },
        { x: e.x, y: e.y, code: 'e', cursor: 'ew-resize' },
        { x: se.x, y: se.y, code: 'se', cursor: 'nwse-resize' },
        { x: s.x, y: s.y, code: 's', cursor: 'ns-resize' },
        { x: sw.x, y: sw.y, code: 'sw', cursor: 'nesw-resize' },
        { x: wpt.x, y: wpt.y, code: 'w', cursor: 'ew-resize' },
        { x: rx, y: ry, code: 'rot', cursor: 'grab' },
      ];
    }
    const corners = [
      { x: obj.x, y: obj.y }, { x: obj.x + obj.w, y: obj.y }, { x: obj.x + obj.w, y: obj.y + obj.h }, { x: obj.x, y: obj.y + obj.h },
    ].map(p => rotatePoint(p.x, p.y, obj.cx, obj.cy, obj.angle));
    const [nw, ne, se, sw] = [corners[0], corners[1], corners[2], corners[3]];
    const mid = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
    const n = mid(nw, ne), e = mid(ne, se), s = mid(se, sw), w = mid(sw, nw);
    const dir = { x: n.x - obj.cx, y: n.y - obj.cy };
    const len = Math.hypot(dir.x, dir.y) || 1;
    const rx = n.x + dir.x / len * ROTATE_HANDLE_OFFSET;
    const ry = n.y + dir.y / len * ROTATE_HANDLE_OFFSET;

    const hs = [
      { x: nw.x, y: nw.y, code: 'nw', cursor: 'nwse-resize' },
      { x: n.x, y: n.y, code: 'n', cursor: 'ns-resize' },
      { x: ne.x, y: ne.y, code: 'ne', cursor: 'nesw-resize' },
      { x: e.x, y: e.y, code: 'e', cursor: 'ew-resize' },
      { x: se.x, y: se.y, code: 'se', cursor: 'nwse-resize' },
      { x: s.x, y: s.y, code: 's', cursor: 'ns-resize' },
      { x: sw.x, y: sw.y, code: 'sw', cursor: 'nesw-resize' },
      { x: w.x, y: w.y, code: 'w', cursor: 'ew-resize' },
      { x: rx, y: ry, code: 'rot', cursor: 'grab' },
    ];
    if (obj.type === 'lshape' || obj.type === 'cshape') {
      const vLocal = { x: -obj.w / 2 + (obj.tV ?? Math.min(obj.w, obj.h) * 0.35), y: 0 };
      const vWorld = rotatePoint(obj.cx + vLocal.x, obj.cy + vLocal.y, obj.cx, obj.cy, obj.angle);
      const hLocal = { x: 0, y: -obj.h / 2 + (obj.tH ?? Math.min(obj.w, obj.h) * 0.35) };
      const hWorld = rotatePoint(obj.cx + hLocal.x, obj.cy + hLocal.y, obj.cx, obj.cy, obj.angle);
      hs.push({ x: vWorld.x, y: vWorld.y, code: 'thickV', cursor: 'ew-resize' });
      hs.push({ x: hWorld.x, y: hWorld.y, code: 'thickH', cursor: 'ns-resize' });
    }
    return hs;
  }
  function drawHandles(obj) {
    if (state.selection.size !== 1) return;
    const handles = getHandles(obj);
    ctx.save();
    for (const h of handles) {
      let stroke = '#00bcd4';
      if (h.code === 'rot') stroke = '#ff5722';
      if (h.code === 'thickV') stroke = '#8b5cf6';
      if (h.code === 'thickH') stroke = '#10b981';
      ctx.fillStyle = '#fff'; ctx.strokeStyle = stroke; ctx.lineWidth = 1.2;
      ctx.beginPath();
      if (h.code === 'rot') ctx.arc(h.x, h.y, 6, 0, Math.PI * 2);
      else ctx.rect(h.x - HANDLE_SIZE / 2, h.y - HANDLE_SIZE / 2, HANDLE_SIZE, HANDLE_SIZE);
      ctx.fill(); ctx.stroke();
    }
    ctx.restore();
  }
  function hitHandle(obj, mx, my) {
    const handles = getHandles(obj);
    const half = HANDLE_SIZE / 2 + HIT_PAD;
    for (const h of handles) {
      if (h.code === 'rot') {
        if (Math.hypot(mx - h.x, my - h.y) <= (half + 2)) return h;
      } else {
        if (pointInRect(mx, my, h.x - half, h.y - half, half * 2, half * 2)) return h;
      }
    }
    return null;
  }

  /* =========================================================
   * [세션 6] UI 이벤트
   * =======================================================*/
  function setTool(t) { state.tool = t; setActiveToolButton(t); setStatus(`툴: ${t}`); }
  chkSnap?.addEventListener('change', () => state.snap = chkSnap.checked);
  gridSizeInput?.addEventListener('change', () => {
    const v = parseInt(gridSizeInput.value || '10', 10);
    state.gridSize = Math.floor(Math.max(4, v));
    render();
  });

  function getMousePos(evt) {
    const r = canvas.getBoundingClientRect();
    const x = (evt.clientX - r.left) * (canvas.width / r.width);
    const y = (evt.clientY - r.top) * (canvas.height / r.height);
    return { x, y };
  }
  function hitTest(x, y, ignoreIds = null) {
    for (let i = state.objects.length - 1; i >= 0; i--) {
      const obj = state.objects[i]; if (!obj) continue;
      if (ignoreIds && ignoreIds.has(obj.id)) continue;
      if (obj.kind === 'group') {
        const b = obj.bbox();
        if (pointInRect(x, y, b.x, b.y, b.w, b.h)) return obj;
      } else {
        if (obj.hit && obj.hit(x, y)) return obj;
      }
    }
    return null;
  }
  function hitTestPreferUnselected(x, y) {
    const target1 = hitTest(x, y, state.selection);
    if (target1) return target1;
    return hitTest(x, y, null);
  }

  /* =========================================================
   * [세션 7] 리사이즈/회전
   * =======================================================*/
  function applyResize(obj, handleCode, startBBox, startMouse, curMouse) {
    if ((handleCode === 'thickV' || handleCode === 'thickH') && (obj.type === 'lshape' || obj.type === 'cshape')) {
      const cx = obj.cx, cy = obj.cy;
      const sm = invRotatePoint(startMouse.x, startMouse.y, cx, cy, obj.angle);
      const cm = invRotatePoint(snap(curMouse.x), snap(curMouse.y), cx, cy, obj.angle);

      let sens = THICK_SENS;
      if (state.keymods.shift) sens *= THICK_FINE;
      if (state.keymods.alt) sens *= THICK_COARSE;

      const baseTV = state.resizeStartThick.tV ?? (obj.tV ?? Math.min(obj.w, obj.h) * 0.35);
      const baseTH = state.resizeStartThick.tH ?? (obj.tH ?? Math.min(obj.w, obj.h) * 0.35);

      if (handleCode === 'thickV') {
        let next = baseTV + (cm.x - sm.x) * sens;
        const step = state.snap ? Math.max(1, state.gridSize) : THICK_STEP;
        next = roundTo(next, step);
        obj.tV = Math.max(5, Math.min(obj.w - 5, next));
      } else {
        let next = baseTH + (cm.y - sm.y) * sens;
        const step = state.snap ? Math.max(1, state.gridSize) : THICK_STEP;
        next = roundTo(next, step);
        obj.tH = Math.max(5, Math.min(obj.h - 5, next));
      }
      return;
    }

    if (obj.kind === 'group') {
      if (!state.groupResizeSnapshot) return;
      const ob = startBBox;
      let lx = ob.x, ly = ob.y, lw = ob.w, lh = ob.h;

      const dx = snap(curMouse.x) - startMouse.x;
      const dy = snap(curMouse.y) - startMouse.y;

      if (handleCode.includes('n')) { ly += dy; lh -= dy; }
      if (handleCode.includes('s')) { lh += dy; }
      if (handleCode.includes('w')) { lx += dx; lw -= dx; }
      if (handleCode.includes('e')) { lw += dx; }

      lw = Math.max(10, lw); lh = Math.max(10, lh);

      const sx = lw / (ob.w || 1);
      const sy = lh / (ob.h || 1);

      state.groupResizeSnapshot.forEach(s => {
        const child = getObj(s.id); if (!child) return;

        if (s.type === 'poly' && s.points) {
          child.meta.points = s.points.map(p => ({ x: lx + (p.x - ob.x) * sx, y: ly + (p.y - ob.y) * sy }));
          const xs = child.meta.points.map(p => p.x), ys = child.meta.points.map(p => p.y);
          child.x = Math.min(...xs); child.y = Math.min(...ys);
          child.w = Math.max(...xs) - child.x; child.h = Math.max(...ys) - child.y;
          child.angle = s.angle;
        } else {
          const cxNew = lx + (s.cx - ob.x) * sx;
          const cyNew = ly + (s.cy - ob.y) * sy;
          const wNew = Math.max(1, s.w * sx);
          const hNew = Math.max(1, s.h * sy);
          child.x = cxNew - wNew / 2; child.y = cyNew - hNew / 2;
          child.w = wNew; child.h = hNew; child.angle = s.angle;
          if (child.type === 'lshape' || child.type === 'cshape') {
            if (typeof s.tV === 'number') child.tV = Math.max(1, s.tV * sx);
            if (typeof s.tH === 'number') child.tH = Math.max(1, s.tH * sy);
          }
        }
      });
      return;
    }

    const cx = obj.cx, cy = obj.cy;
    const sm = invRotatePoint(startMouse.x, startMouse.y, cx, cy, obj.angle);
    const cm = invRotatePoint(snap(curMouse.x), snap(curMouse.y), cx, cy, obj.angle);

    let { x, y, w, h } = startBBox;
    const rNW = invRotatePoint(x, y, cx, cy, obj.angle);
    const rSE = invRotatePoint(x + w, y + h, cx, cy, obj.angle);
    let lx2 = rNW.x, ly2 = rNW.y, lw2 = rSE.x - rNW.x, lh2 = rSE.y - rNW.y;

    const dx2 = cm.x - sm.x, dy2 = cm.y - sm.y;
    if (handleCode.includes('n')) { ly2 += dy2; lh2 -= dy2; }
    if (handleCode.includes('s')) { lh2 += dy2; }
    if (handleCode.includes('w')) { lx2 += dx2; lw2 -= dx2; }
    if (handleCode.includes('e')) { lw2 += dx2; }

    lw2 = Math.max(10, lw2); lh2 = Math.max(10, lh2);
    const nwc = rotatePoint(lx2 + lw2 / 2, ly2 + lh2 / 2, cx, cy, obj.angle);
    obj.x = nwc.x - lw2 / 2; obj.y = nwc.y - lh2 / 2; obj.w = lw2; obj.h = lh2;

    if (obj.type === 'poly' && state.resizeRefPoints) {
      const ob = startBBox;
      const obLocalNW = invRotatePoint(ob.x, ob.y, cx, cy, obj.angle);
      const obLocalSE = invRotatePoint(ob.x + ob.w, ob.y + ob.h, cx, cy, obj.angle);
      const obW = obLocalSE.x - obLocalNW.x, obH = obLocalSE.y - obLocalNW.y;
      const sx = lw2 / (obW || 1), sy = lh2 / (obH || 1);

      const newPts = state.resizeRefPoints.map(p => {
        const pl = invRotatePoint(p.x, p.y, cx, cy, obj.angle);
        const rx = (pl.x - obLocalNW.x) * sx + (lx2);
        const ry = (pl.y - obLocalNW.y) * sy + (ly2);
        const pw = rotatePoint(rx, ry, cx, cy, obj.angle);
        return { x: pw.x, y: pw.y };
      });
      obj.meta.points = newPts;
    }

    if (obj.type === 'lshape' || obj.type === 'cshape') {
      obj.tV = Math.max(1, Math.min(obj.w - 1, obj.tV ?? Math.min(obj.w, obj.h) * 0.35));
      obj.tH = Math.max(1, Math.min(obj.h - 1, obj.tH ?? Math.min(obj.w, obj.h) * 0.35));
    }
  }

  function applyRotate(obj, anchor, startMouse, curMouse, startAngle) {
    const a1 = Math.atan2(startMouse.y - anchor.y, startMouse.x - anchor.x);
    const a2 = Math.atan2(curMouse.y - anchor.y, curMouse.x - anchor.x);
    const delta = a2 - a1;

    if (obj.kind === 'group') {
      if (!state.groupRotateSnapshot) return;
      state.groupRotateSnapshot.forEach(s => {
        const child = getObj(s.id); if (!child) return;
        const rc = rotatePoint(s.cx, s.cy, anchor.x, anchor.y, delta);

        if (s.type === 'poly' && s.points) {
          child.meta.points = s.points.map(p => rotatePoint(p.x, p.y, anchor.x, anchor.y, delta));
          const xs = child.meta.points.map(p => p.x), ys = child.meta.points.map(p => p.y);
          child.x = Math.min(...xs); child.y = Math.min(...ys);
          child.w = Math.max(...xs) - child.x; child.h = Math.max(...ys) - child.y;
          child.angle = s.angle;
        } else {
          child.w = s.w; child.h = s.h;
          child.x = rc.x - child.w / 2; child.y = rc.y - child.h / 2;
          child.angle = (s.angle || 0) + delta;
        }
      });
      return;
    }
    obj.angle = startAngle + delta;
  }

  /* =========================================================
   * [세션 8] 마우스/키보드 이벤트
   * =======================================================*/
  canvas.addEventListener('mousedown', (e) => {
    const m = getMousePos(e);
    state.lastMouse = m;

    if (SHAPE_TOOLS.has(state.tool) && state.tool !== 'select') {
      if (state.tool === 'line') {
        // 라인(펜) 시작
        if (!state.tracing) { state.tracing = true; state.tracePoints = []; }
        state.tracePoints.push({ x: snap(m.x), y: snap(m.y) });
        render();
        return;
      }
      state.creating = { type: state.tool, start: { x: snap(m.x), y: snap(m.y) }, end: { x: snap(m.x), y: snap(m.y) } };
      setStatus('drag create'); return;
    }

    if (state.selection.size === 1) {
      const selObj = getObj([...state.selection][0]);
      const h = hitHandle(selObj, m.x, m.y);
      if (h) {
        if (h.code === 'rot') {
          state.rotating = true; state.rotateTargetId = selObj.id; state.rotateStartMouse = { x: m.x, y: m.y };
          if (selObj.kind === 'group') {
            const { cx, cy } = groupCenter(selObj); state.rotateAnchor = { x: cx, y: cy };
            state.groupRotateSnapshot = selObj.children.map(id => {
              const o = getObj(id);
              return { id: o.id, type: o.type, cx: o.x + o.w / 2, cy: o.y + o.h / 2, w: o.w, h: o.h, angle: o.angle || 0, points: (o.type === 'poly') ? o.meta.points.map(p => ({ x: p.x, y: p.y })) : null };
            });
            state.rotateStartAngle = 0;
          } else {
            state.rotateAnchor = { x: selObj.cx, y: selObj.cy };
            state.rotateStartAngle = selObj.angle || 0;
            state.groupRotateSnapshot = null;
          }
          canvas.style.cursor = 'grabbing'; return;
        } else {
          state.resizing = true; state.activeHandle = h.code; state.resizeTargetId = selObj.id;
          state.resizeStartMouse = { x: snap(m.x), y: snap(m.y) };
          state.resizeStartBBox = { ...selObj.bbox() };
          state.resizeRefPoints = selObj.type === 'poly' ? selObj.meta.points.map(p => ({ x: p.x, y: p.y })) : null;

          if (selObj.kind === 'group') {
            state.groupResizeSnapshot = selObj.children.map(id => {
              const o = getObj(id);
              return { id: o.id, type: o.type, cx: o.x + o.w / 2, cy: o.y + o.h / 2, w: o.w, h: o.h, angle: o.angle || 0, points: (o.type === 'poly') ? o.meta.points.map(p => ({ x: p.x, y: p.y })) : null, tH: (o.type === 'lshape' || o.type === 'cshape') ? o.tH : undefined, tV: (o.type === 'lshape' || o.type === 'cshape') ? o.tV : undefined };
            });
          } else { state.groupResizeSnapshot = null; }

          if ((h.code === 'thickV' || h.code === 'thickH') && (selObj.type === 'lshape' || selObj.type === 'cshape')) {
            state.resizeStartThick.tV = selObj.tV ?? Math.min(selObj.w, selObj.h) * 0.35;
            state.resizeStartThick.tH = selObj.tH ?? Math.min(selObj.w, selObj.h) * 0.35;
          } else {
            state.resizeStartThick.tV = null; state.resizeStartThick.tH = null;
          }
          canvas.style.cursor = h.cursor; return;
        }
      }
    }

    let target;
    if (e.ctrlKey) target = hitTestPreferUnselected(m.x, m.y);
    else target = hitTest(m.x, m.y);

    if (state.tool === 'select') {
      if (target) {
        if (e.ctrlKey) {
          if (state.selection.has(target.id)) state.selection.delete(target.id);
          else state.selection.add(target.id);
          state.dragging = false; state.maybeDragging = false;
        } else {
          state.selection.clear(); state.selection.add(target.id);
          state.maybeDragging = true; state.dragging = false;
          state.dragStart = { x: snap(m.x), y: snap(m.y) };
        }
      } else {
        if (!e.ctrlKey) state.selection.clear();
      }
      render(); return;
    }
  });

  canvas.addEventListener('mousemove', (e) => {
    const m = getMousePos(e);
    state.lastMouse = m;

    if (state.creating && state.creating.type !== 'line') {
      state.creating.end = { x: snap(m.x), y: snap(m.y) };
      render(); return;
    }

    if (state.tracing && state.tool === 'line') { /* 시각 가이드만 */ return; }

    if (state.rotating) {
      const obj = getObj(state.rotateTargetId);
      if (obj) { applyRotate(obj, state.rotateAnchor, state.rotateStartMouse, m, state.rotateStartAngle); setStatus(`回転`); render(); }
      return;
    }
    if (state.resizing) {
      const obj = getObj(state.resizeTargetId);
      if (obj) { applyResize(obj, state.activeHandle, state.resizeStartBBox, state.resizeStartMouse, m); render(); }
      return;
    }

    if (state.maybeDragging && state.selection.size > 0) {
      const dx0 = snap(m.x) - state.dragStart.x;
      const dy0 = snap(m.y) - state.dragStart.y;
      if (Math.hypot(dx0, dy0) >= DRAG_START_THRESHOLD) { state.dragging = true; state.maybeDragging = false; }
    }
    if (state.dragging && state.selection.size > 0) {
      const dx = snap(m.x) - state.dragStart.x;
      const dy = snap(m.y) - state.dragStart.y;
      if (dx !== 0 || dy !== 0) {
        for (const id of state.selection) { const obj = getObj(id); if (obj) obj.moveBy(dx, dy); }
        state.dragStart = { x: snap(m.x), y: snap(m.y) };
        render();
      }
      return;
    }

    canvas.style.cursor = 'crosshair';
    if (state.selection.size === 1) {
      const selObj = getObj([...state.selection][0]);
      if (selObj) {
        const h = hitHandle(selObj, m.x, m.y);
        if (h) { canvas.style.cursor = h.code === 'rot' ? 'grab' : h.cursor; setStatus(h.code); return; }
      }
    }
    const hover = hitTest(m.x, m.y);
    if (hover) { canvas.style.cursor = 'move'; setStatus('移動可能'); }
    else { setStatus(`x:${Math.round(m.x)} y:${Math.round(m.y)}`); }
  });

  canvas.addEventListener('mouseup', (e) => {
    if (state.creating && state.creating.type !== 'line') {
      const { type, start } = state.creating;
      const m = getMousePos(e);
      const end = { x: snap(m.x), y: snap(m.y) };
      const x1 = Math.min(start.x, end.x), y1 = Math.min(start.y, end.y);
      const x2 = Math.max(start.x, end.x), y2 = Math.max(start.y, end.y);
      const w = Math.max(1, x2 - x1), h = Math.max(1, y2 - y1);

      if (w >= 3 && h >= 3) {
        let obj = null;
        if (type === 'rect') obj = new Rect({ x: x1, y: y1, w, h });
        if (type === 'tri') obj = new Tri({ x: x1, y: y1, w, h });
        if (type === 'circle') obj = new Circle({ x: x1, y: y1, w, h });
        if (type === 'lshape') obj = new LShape({ x: x1, y: y1, w, h });
        if (type === 'cshape') obj = new CShape({ x: x1, y: y1, w, h });
        if (obj) { state.objects.push(obj); state.selection.clear(); state.selection.add(obj.id); }
      }
      state.creating = null;
      state.tool = 'select'; setActiveToolButton('select'); canvas.style.cursor = 'crosshair'; setStatus('選択モード'); render();
    }

    state.dragging = false; state.maybeDragging = false;
    state.resizing = false; state.rotating = false;
    state.activeHandle = null; state.resizeTargetId = null; state.rotateTargetId = null;
    state.resizeRefPoints = null; state.groupResizeSnapshot = null; state.groupRotateSnapshot = null;
    state.resizeStartThick.tV = null; state.resizeStartThick.tH = null;
    canvas.style.cursor = 'crosshair';
  });

  // 펜(라인) 더블클릭/Enter로 확정 (좌표만 사용)
  canvas.addEventListener('dblclick', () => { if (state.tool === 'line' && state.tracing && state.tracePoints.length >= 3) finishPen(); });
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Delete') { deleteSelection(); }
    if (e.key === 'Enter') { if (state.tool === 'line' && state.tracing && state.tracePoints.length >= 3) finishPen(); }
    if (e.key === 'Escape') { if (state.tool === 'line' && state.tracing) cancelPen(); if (state.creating) { state.creating = null; render(); } }
    if (e.key === 'Shift') state.keymods.shift = true;
    if (e.key === 'Alt') state.keymods.alt = true;
  });
  window.addEventListener('keyup', (e) => { if (e.key === 'Shift') state.keymods.shift = false; if (e.key === 'Alt') state.keymods.alt = false; });

  function setStatus(msg) { statusEl && (statusEl.textContent = msg); }
  function finishPen() {
    const pts = state.tracePoints.slice();
    state.tracing = false; state.tracePoints = [];
    const poly = new Poly(pts);
    state.objects.push(poly);
    state.selection.clear(); state.selection.add(poly.id);
    state.tool = 'select'; setActiveToolButton('select'); canvas.style.cursor = 'crosshair';
    setStatus('ペン図形完了＞選択モード切り替え'); render();
  }
  function cancelPen() { state.tracing = false; state.tracePoints = []; setStatus('ペンキャンセル'); render(); }

  /* =========================================================
   * [세션 9] 도형→MultiPolygon 변환 (내부 연산 전용)
   *  - 저장은 이 결과에서 outer ring만 뽑아 좌표 배열로 기록
   * =======================================================*/
  function ringSignedArea(ring) {
    let a = 0; for (let i = 0; i < ring.length; i++) { const p = ring[i], q = ring[(i + 1) % ring.length]; a += p.x * q.y - p.y * q.x; }
    return a;
  }
  function ensureCCW(ring) { const arr = ring.slice(); if (ringSignedArea(arr) < 0) arr.reverse(); return arr; }
  function isClosedRing(ring) { if (!ring || ring.length < 2) return false; const [x0, y0] = ring[0], [xn, yn] = ring[ring.length - 1]; return Math.abs(x0 - xn) <= 1e-6 && Math.abs(y0 - yn) <= 1e-6; }
  function stripClosure(ring) { if (!Array.isArray(ring) || ring.length < 2) return ring; return isClosedRing(ring) ? ring.slice(0, ring.length - 1) : ring; }

  function shapeToPolygon(o) {
    const pts = []; const cx = o.x + o.w / 2, cy = o.y + o.h / 2;
    if (o.type === 'rect') {
      [{ x: o.x, y: o.y }, { x: o.x + o.w, y: o.y }, { x: o.x + o.w, y: o.y + o.h }, { x: o.x, y: o.y + o.h }]
        .forEach(p => pts.push(rotatePoint(p.x, p.y, cx, cy, o.angle || 0)));
    }
    else if (o.type === 'tri') {
      [{ x: cx, y: o.y }, { x: o.x + o.w, y: o.y + o.h }, { x: o.x, y: o.y + o.h }]
        .forEach(p => pts.push(rotatePoint(p.x, p.y, cx, cy, o.angle || 0)));
    }
    else if (o.type === 'circle') {
      const N = 48;
      for (let i = 0; i < N; i++) {
        const t = i / N * Math.PI * 2;
        const px = cx + (o.w / 2) * Math.cos(t);
        const py = cy + (o.h / 2) * Math.sin(t);
        pts.push(rotatePoint(px, py, cx, cy, o.angle || 0));
      }
    }
    else if (o.type === 'lshape' || o.type === 'cshape') {
      const w = o.w, h = o.h;
      const tH = o.tH ?? Math.min(w, h) * (o.type === 'lshape' ? 0.4 : 0.3);
      const tV = o.tV ?? Math.min(w, h) * (o.type === 'lshape' ? 0.4 : 0.3);
      let raw;
      if (o.type === 'lshape') {
        raw = [
          { x: -w / 2, y: -h / 2 },
          { x: w / 2, y: -h / 2 },
          { x: w / 2, y: -h / 2 + tH },
          { x: -w / 2 + tV, y: -h / 2 + tH },
          { x: -w / 2 + tV, y: h / 2 },
          { x: -w / 2, y: h / 2 },
        ];
      } else {
        raw = [
          { x: -w / 2, y: -h / 2 },
          { x: w / 2, y: -h / 2 },
          { x: w / 2, y: -h / 2 + tH },
          { x: -w / 2 + tV, y: -h / 2 + tH },
          { x: -w / 2 + tV, y: h / 2 - tH },
          { x: w / 2, y: h / 2 - tH },
          { x: w / 2, y: h / 2 },
          { x: -w / 2, y: h / 2 },
        ];
      }
      raw.forEach(lp => { const wx = cx + lp.x, wy = cy + lp.y; pts.push(rotatePoint(wx, wy, cx, cy, o.angle || 0)); });
    }
    else if (o.type === 'poly') { (o.meta.points || []).forEach(p => pts.push({ x: p.x, y: p.y })); }
    const ring = ensureCCW(pts).map(p => [p.x, p.y]);
    return [[ring]];
  }
  function groupToPolygons(g, pc) {
    const polys = g.children.map(id => shapeToPolygon(getObj(id)));
    return pc.union(...polys);
  }

  /* =========================================================
   * [세션 10] 삭제/그룹/해제
   * =======================================================*/
  function deleteSelection() {
    if (state.selection.size === 0) return;
    const toDelete = new Set();
    for (const id of state.selection) {
      const o = getObj(id); if (!o) continue;
      if (o.kind === 'group') { toDelete.add(o.id); o.children.forEach(cid => toDelete.add(cid)); }
      else { toDelete.add(o.id); }
    }
    state.objects = state.objects
      .map(o => {
        if (!o) return null;
        if (toDelete.has(o.id)) return null;
        if (o.kind === 'group') {
          o.children = o.children.filter(cid => !toDelete.has(cid));
          if (o.children.length < 2) return null;
        }
        return o;
      })
      .filter(Boolean);
    state.selection.clear(); render();
  }
  btnDelete?.addEventListener('click', deleteSelection);

  btnGroup?.addEventListener('click', () => {
    if (state.selection.size < 2) return;
    const selectedIds = [...state.selection];
    const shapeIds = new Set(); const groupIds = new Set();
    selectedIds.forEach(id => { const o = getObj(id); if (!o) return; if (o.kind === 'group') { groupIds.add(o.id); o.children.forEach(cid => shapeIds.add(cid)); } else { shapeIds.add(o.id); } });
    const finalIds = [...shapeIds]; if (finalIds.length < 2) return;
    state.objects = state.objects.filter(o => o && !groupIds.has(o.id));
    const g = new Group(finalIds); state.objects.push(g);
    state.selection.clear(); state.selection.add(g.id); render();
  });

  btnUngroup?.addEventListener('click', () => {
    const ids = [...state.selection]; let changed = false;
    ids.forEach(id => { const o = getObj(id); if (o && o.kind === 'group') { state.objects = state.objects.filter(x => x && x.id !== o.id); state.selection.delete(id); changed = true; } });
    if (changed) render();
  });

  /* =========================================================
   * [세션 11] 저장 버튼 — “좌표만” 내보내기
   *  - 최상위 첫 객체의 외곽선을 MultiPolygon에서 outer ring으로 뽑아
   *    정수 반올림 좌표 배열만 coords에 담아 저장
   * =======================================================*/
btnSaveJSON?.addEventListener('click', async () => {
  await ensurePc(); // 그룹일 때 합집합 추출 필요

  // 1) 최상위 오브젝트 추출 (기존 로직 그대로)
  const groupedChildIds = new Set();
  state.objects.forEach(o => { if (o?.kind === 'group') o.children.forEach(id => groupedChildIds.add(id)); });
  const topLevel = state.objects.filter(o => o && (o.kind === 'group' || !groupedChildIds.has(o.id)));
  if (!topLevel.length) return;

  const obj = topLevel[0]; // ★ 좌표/이미지 모두 동일 기준

  // 2) 외곽선 멀티폴리곤 (좌표 저장용)
  const mp = (obj.kind === 'group')
    ? (pcLib ? groupToPolygons(obj, pcLib) : null)
    : shapeToPolygon(obj);

  if (!mp || !mp[0] || !mp[0][0]) {
    console.warn('外郭抽出に失敗: polygon data missing');
    return;
  }

  // 3) coords만 저장 (기존과 동일)
  const outer = mp[0][0];
  const coords = stripClosure(outer).map(([x, y]) => [Math.round(x), Math.round(y)]);
  const payload = {
    version: 1,
    coords,                           // ★ 오로지 좌표만
    canvas: { w: canvas.width, h: canvas.height },
    ts: Date.now(),
  };
  sessionStorage.setItem('floorCoordsPayload', JSON.stringify(payload));

  // 4) PNG 타이트 크롭 저장 (새로 추가)
  //    - 파일명/패딩은 필요에 맞게 바꿔도 OK
  await exportCroppedPNGOfObject(obj, 'shape.png', 6);

  // 5) 다음 페이지 이동 (기존 동작 유지)
  window.location.href = 'building_img.html';
});


  /* =========================================================
   * [세션 12] 초기화
   * =======================================================*/
  async function init() {
    await ensurePc();
    state.snap = chkSnap?.checked ?? false;
    state.gridSize = parseInt(gridSizeInput?.value || '10', 10) || 10;
    render();
  }
  init();
})();