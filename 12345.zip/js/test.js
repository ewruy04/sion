import * as THREE from 'https://unpkg.com/three@0.160.0/build/three.module.js';
import { OrbitControls } from 'https://unpkg.com/three@0.160.0/examples/jsm/controls/OrbitControls.js';

const container = document.getElementById('viewer');

// ───────────────────────────────────────────────────────────
// 기본 세팅
// ───────────────────────────────────────────────────────────
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(container.clientWidth, container.clientHeight);
renderer.shadowMap.enabled = true;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.NoToneMapping;
renderer.toneMappingExposure = 1.0;
container.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xf3f6fa);

const camera = new THREE.PerspectiveCamera(55, container.clientWidth / container.clientHeight, 0.1, 5000);
camera.position.set(200, 260, 320);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.08;
controls.minDistance = 1;
controls.update();

scene.add(new THREE.HemisphereLight(0xffffff, 0x667788, 0.7));

const buildingGroup = new THREE.Group();
buildingGroup.name = 'buildingGroup';
scene.add(buildingGroup);

// ───────────────────────────────────────────────────────────
// 유틸: 다각형 내부판정 / u-구간 계산
// ───────────────────────────────────────────────────────────
function pointInPoly([x, y], poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i], [xj, yj] = poly[j];
    const hit = ((yi > y) !== (yj > y)) &&
                (x < (xj - xi) * (y - yi) / ((yj - yi) || 1e-9) + xi);
    if (hit) inside = !inside;
  }
  return inside;
}

function computeBlockedURanges(ellipsePts, blockerPolys) {
  const N = ellipsePts.length;
  const segLen = new Array(N);
  let total = 0;
  for (let i = 0; i < N; i++) {
    const a = ellipsePts[i], b = ellipsePts[(i + 1) % N];
    const L = Math.hypot(b[0] - a[0], b[1] - a[1]);
    segLen[i] = L; total += L;
  }
  const segU = new Array(N);
  let acc = 0;
  for (let i = 0; i < N; i++) {
    segU[i] = [acc / total, (acc + segLen[i]) / total];
    acc += segLen[i];
  }

  const blocked = new Array(N).fill(false);
  for (let i = 0; i < N; i++) {
    const a = ellipsePts[i], b = ellipsePts[(i + 1) % N];
    const mid = [(a[0] + b[0]) * 0.5, (a[1] + b[1]) * 0.5];
    for (const poly of blockerPolys) {
      if (poly?.length >= 3 && pointInPoly(mid, poly)) { blocked[i] = true; break; }
    }
  }

  const ranges = [];
  let i = 0; const EPS = 1e-4;
  while (i < N) {
    if (!blocked[i]) { i++; continue; }
    let j = i + 1;
    while (j < N && blocked[j]) j++;
    const [u0] = segU[i];
    const [, u1prev] = segU[j - 1];
    if (u1prev - u0 > EPS) ranges.push([u0, u1prev]);
    i = j;
  }
  if (ranges.length >= 2 && blocked[0] && blocked[N - 1]) {
    const first = ranges[0], last = ranges[ranges.length - 1];
    ranges[0] = [last[0], first[1]];
    ranges.pop();
  }
  return ranges;
}

function complementRanges(blocked) {
  const EPS = 1e-4;
  if (!blocked?.length) return [[0,1]];
  blocked = blocked.slice().sort((a,b)=>a[0]-b[0]);
  const out = [];
  let cur = 0;
  for (const [a,b] of blocked) {
    if (a - cur > EPS) out.push([cur, a]);
    cur = Math.max(cur, b);
  }
  if (1 - cur > EPS) out.push([cur, 1]);
  return out;
}

function intersectSpanWithRanges([uA, uB], ranges, EPS = 1e-6) {
  const out = [];
  for (const [a,b] of ranges) {
    const s = Math.max(uA, a);
    const e = Math.min(uB, b);
    if (e - s > EPS) out.push([s, e]);
  }
  return out;
}

// ───────────────────────────────────────────────────────────
// 타입 보존 JSON → 폴리곤 포인트(타원 샘플링 포함)
// ───────────────────────────────────────────────────────────
function sampleEllipse({ cx, cy, rx, ry, angle = 0 }, segments = 64) {
  const pts = [];
  const cosR = Math.cos(angle), sinR = Math.sin(angle);
  for (let i = 0; i < segments; i++) {
    const t = (i / segments) * Math.PI * 2;
    const ex = rx * Math.cos(t);
    const ey = ry * Math.sin(t);
    const rxed = ex * cosR - ey * sinR;
    const ryed = ex * sinR + ey * cosR;
    pts.push([Math.round(cx + rxed), Math.round(cy + ryed)]);
  }
  return pts;
}

function shapesToPolyObjs(saved, ellipseSegments = 72) {
  if (!saved || !Array.isArray(saved.shapes)) return [];
  const out = [];
  for (const sh of saved.shapes) {
    if (sh.type === 'polygon' && Array.isArray(sh.points) && sh.points.length >= 3) {
      out.push({ points: sh.points, type: 'polygon', id: sh.id, role: sh.role });
    } else if (sh.type === 'ellipse') {
      const pts = sampleEllipse({ cx: sh.cx, cy: sh.cy, rx: sh.rx, ry: sh.ry, angle: sh.angle || 0 }, ellipseSegments);
      out.push({ points: pts, type: 'ellipse', id: sh.id, role: sh.role, __ellipseMeta: { cx: sh.cx, cy: sh.cy, rx: sh.rx, ry: sh.ry, angle: sh.angle || 0 } });
    }
  }
  return out;
}

// ───────────────────────────────────────────────────────────
// 데이터 로드(세션 → 인라인 → 폴백)
// ───────────────────────────────────────────────────────────
let baseHeight = 600;
let loadedPolys = null;

const SAVED_INLINE = {
  "version": 1,
  "units": "px",
  "canvasSize": { "width": 1600, "height": 1000 },
  "shapes": [
    {
      "id": "id_5_outline",
      "kind": "group",
      "type": "polygon",
      "points": [
        [447,245],[551,94],[655,245],[587,245],[586,328],[741,330],[744,324],[749,316],
        [756,309],[763,303],[771,298],[780,294],[789,291],[799,289],[809,288],[818,289],
        [828,291],[837,294],[846,298],[854,303],[862,309],[868,316],[873,324],[878,332],
        [881,341],[883,350],[883,360],[883,369],[881,378],[878,387],[873,395],[868,403],
        [862,410],[854,416],[846,421],[837,426],[828,429],[818,430],[809,431],[799,430],
        [789,429],[780,426],[771,421],[763,416],[756,410],[749,403],[746,398],[516,395],[518,245]
      ],
      "role": "outline"
    },
    {
      "id": "id_1",
      "kind": "shape",
      "style": { "fill": "#f5f9ffff", "stroke": "#222", "lineWidth": 2 },
      "type": "polygon",
      "points": [[551,94],[655,245],[447,245]]
    },
    {
      "id": "id_2",
      "kind": "shape",
      "style": { "fill": "#f5f9ffff", "stroke": "#222", "lineWidth": 2 },
      "type": "polygon",
      "points": [[516,395],[519,224],[587,225],[586,328],[767,330],[766,399]]
    },
    {
      "id": "id_4",
      "kind": "shape",
      "type": "ellipse",
      "cx": 809, "cy": 360, "rx": 75, "ry": 71, "angle": 0,
      "style": { "fill": "#f5f9ffff", "stroke": "#222", "lineWidth": 2 }
    }
  ]
};

try {
  let saved = null;
  const raw = sessionStorage.getItem('floorShapesLatest');
  if (raw) saved = JSON.parse(raw);
  if (!saved && SAVED_INLINE) saved = SAVED_INLINE;

  if (saved) {
    if (saved?.canvasSize?.height) baseHeight = saved.canvasSize.height;
    const objs = shapesToPolyObjs(saved, 72);

    let primaryObj = objs.find(o => o.role === 'outline' && o.points?.length >= 3);
    if (!primaryObj && objs.length) {
      const area = (pts) => Math.abs(
        pts.reduce((acc, [x1,y1], i) => {
          const [x2,y2] = pts[(i+1)%pts.length];
          return acc + (x1*y2 - y1*x2);
        }, 0)
      ) * 0.5;
      primaryObj = objs.slice().sort((a,b)=> area(b.points) - area(a.points))[0];
    }

    loadedPolys = primaryObj ? [primaryObj, ...objs.filter(o => o !== primaryObj)] : objs;
  }
} catch (e) {
  console.warn('Failed to load shapes:', e);
}

if (!loadedPolys) {
  loadedPolys = [{ points: [
    [496,248],[600,97],[704,248],[587,248],[586,328],[741,330],[744,324],[749,316],
    [756,309],[763,303],[771,298],[780,294],[789,291],[799,289],[809,288],[818,289],
    [828,291],[837,294],[846,298],[854,303],[862,309],[868,316],[873,324],[878,332],
    [881,341],[883,350],[883,360],[883,369],[881,378],[878,387],[873,395],[868,403],
    [862,410],[854,416],[846,421],[837,426],[828,429],[818,430],[809,431],[799,430],
    [789,429],[780,426],[771,421],[763,416],[756,410],[749,403],[746,398],[516,395],[518,248]
  ], type: 'polygon', id: 'fallback' }];
}

// 다른 도형과의 겹침 계산용으로 전역에 보관
window.loadedPolyObjs = loadedPolys;

// ───────────────────────────────────────────────────────────
// 카메라 자동 프레이밍
// ───────────────────────────────────────────────────────────
function autoFrame(object, { fitOffset = 1.25 } = {}) {
  if (!object) return;
  const box = new THREE.Box3().setFromObject(object);
  if (!isFinite(box.min.x) || !isFinite(box.max.x)) return;

  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(center);

  const sphere = new THREE.Sphere();
  box.getBoundingSphere(sphere);

  const fovV = THREE.MathUtils.degToRad(camera.fov);
  const fovH = 2 * Math.atan(Math.tan(fovV / 2) * camera.aspect);
  const distV = (sphere.radius * fitOffset) / Math.sin(fovV / 2);
  const distH = (sphere.radius * fitOffset) / Math.sin(fovH / 2);
  const distance = Math.max(distV, distH);

  const dir = new THREE.Vector3(1, 1, 1).normalize();
  controls.target.copy(center);
  camera.position.copy(center).add(dir.multiplyScalar(distance));

  const maxDim = Math.max(size.x, size.y, size.z);
  camera.near = Math.max(distance / 1000, 0.01);
  camera.far = distance + maxDim * 20;
  camera.updateProjectionMatrix();
  controls.update();
}

// ───────────────────────────────────────────────────────────
// Extrude: 폴리곤 1개 → 벽/바닥/지붕 (타원 메타 포함)
// ───────────────────────────────────────────────────────────
function disposeObject(obj) {
  obj.traverse(o => {
    if (o.geometry) o.geometry.dispose();
    if (o.material) {
      if (Array.isArray(o.material)) o.material.forEach(m => {
        if (m.map) m.map.dispose();
        m.dispose?.();
      });
      else {
        if (o.material.map) o.material.map.dispose();
        o.material.dispose?.();
      }
    }
  });
}

function buildOnePolygon(polyObj, baseHeight, floors, color = 0x9bb0c1) {
  const rawPoints = polyObj.points;
  if (!rawPoints || rawPoints.length < 3) return;

  const polygonPx = rawPoints.map(([x, y]) => ({ x, y }));
  const PX_TO_UNIT = 0.3;
  const UNIT_PER_FLOOR = 15;
  const H = floors * UNIT_PER_FLOOR;

  const to3D = (p) => new THREE.Vector2(p.x * PX_TO_UNIT, (baseHeight - p.y) * PX_TO_UNIT);
  const pts = polygonPx.map(to3D);
  const N = pts.length;

  const oneGroup = new THREE.Group();
  oneGroup.userData.isEllipse = (polyObj.type === 'ellipse');
  oneGroup.userData.polyObj  = polyObj; // ★ 클릭시 참조
  oneGroup.name = `oneGroup_${polyObj.id || THREE.MathUtils.generateUUID()}`;

  const wallsGroup = new THREE.Group();
  wallsGroup.name = 'wallsGroup';
  oneGroup.add(wallsGroup);

  // --- 벽 생성(타원 래핑용 메타 포함) ---
  const edges = [];
  let totalLen = 0;
  for (let i = 0; i < N; i++) {
    const a = pts[i];
    const b = pts[(i + 1) % N];
    const len = Math.hypot(b.x - a.x, b.y - a.y);
    if (len > 1e-3) {
      edges.push({ i, a, b, len });
      totalLen += len;
    }
  }

  let accum = 0;
  for (const e of edges) {
    const { i, a, b, len } = e;
    const dx = b.x - a.x, dz = b.y - a.y;
    const midX = (a.x + b.x) / 2, midZ = (a.y + b.y) / 2;
    const ang = Math.atan2(dz, dx);

    const geo = new THREE.PlaneGeometry(len, H);
    const mat = new THREE.MeshStandardMaterial({ color, side: THREE.DoubleSide });
    const wall = new THREE.Mesh(geo, mat);
    wall.name = 'wall';
    wall.position.set(midX, H / 2, midZ);
    wall.rotation.set(0, -ang, 0);
    wall.castShadow = true;

    wall.userData = {
      order: i,
      segLen: len,
      u0: accum / totalLen,
      u1: (accum + len) / totalLen,
      p0: { x: a.x, z: a.y },
      p1: { x: b.x, z: b.y },
      height: H,
      angle: -ang
    };
    accum += len;

    wallsGroup.add(wall);
  }

  // 바닥/지붕
  const capShape = new THREE.Shape();
  pts.forEach((v,i)=> i===0 ? capShape.moveTo(v.x,v.y) : capShape.lineTo(v.x,v.y));
  capShape.closePath();

  const capGeo = new THREE.ShapeGeometry(capShape);
  capGeo.rotateX(-Math.PI / 2);
  const capMat = new THREE.MeshStandardMaterial({ color, side: THREE.DoubleSide });

  const floor = new THREE.Mesh(capGeo.clone(), capMat.clone());
  floor.position.y = 0;
  floor.rotateX(Math.PI);

  const roof = new THREE.Mesh(capGeo.clone(), capMat.clone());
  roof.position.y = H;
  roof.rotateX(Math.PI);

  wallsGroup.add(floor, roof);

  buildingGroup.add(oneGroup);
}

function buildFromPolygons(polyObjs, baseHeight, floors) {
  // 기존 메쉬 정리
  buildingGroup.children.slice().forEach(ch => { disposeObject(ch); buildingGroup.remove(ch); });

  buildingGroup.position.y = -20;
  const palette = [0x566373, 0x4b5563, 0x6b7280, 0x7b8794, 0x94a3b8];
  polyObjs.forEach((po, i) => buildOnePolygon(po, baseHeight, floors, palette[i % palette.length]));
  autoFrame(buildingGroup, { fitOffset: 1.25 });
}

// ───────────────────────────────────────────────────────────
// UI
// ───────────────────────────────────────────────────────────
const floorsInput = document.getElementById('floors');
const buildBtn = document.getElementById('createBuilding');

function createBuilding() {
  const floors = Math.max(1, Number(floorsInput.value || 1));
  buildFromPolygons(loadedPolys, baseHeight, floors);
}
createBuilding();
buildBtn.addEventListener('click', createBuilding);

// ───────────────────────────────────────────────────────────
// 더블클릭 → 텍스처 적용
// - polygon: 맞딱뜨린 wall 1장 교체
// - ellipse: "면 = 한 장" 개념으로 한 장 이미지를 타원 둘레에 연속 래핑
//   (허용 구간: 다른 폴리곤 내부로 겹치는 구간은 자동 제외)
// ───────────────────────────────────────────────────────────
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();
const fileInput = document.getElementById('fileInput');

let pending = null; // { mode:'single'|'ellipse', wall?, oneGroup? }

function findOneGroupAndWalls(start) {
  let node = start;
  while (node && node !== buildingGroup && node !== scene) {
    if (node.parent === buildingGroup) break;
    node = node.parent;
  }
  if (!node || node === scene) return { oneGroup: null, wallsGroup: null };
  const oneGroup = node;
  const wallsGroup = oneGroup.getObjectByName('wallsGroup');
  return { oneGroup, wallsGroup };
}

renderer.domElement.addEventListener('dblclick', (e) => {
  const rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
  mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

  raycaster.setFromCamera(mouse, camera);
  const hits = raycaster.intersectObjects(buildingGroup.children, true);
  if (!hits.length) return;

  const { oneGroup, wallsGroup } = findOneGroupAndWalls(hits[0].object);
  if (!oneGroup || !wallsGroup) return;

  if (oneGroup.userData?.isEllipse) {
    pending = { mode: 'ellipse', oneGroup };
  } else {
    const wall = hits[0].object.name === 'wall' ? hits[0].object : null;
    if (!wall) return;
    pending = { mode: 'single', wall };
  }

  fileInput.value = '';
  fileInput.click();
});

fileInput.addEventListener('change', (e) => {
  const f = e.target.files?.[0];
  if (!f || !pending) return;

  const url = URL.createObjectURL(f);
  new THREE.TextureLoader().load(url, (baseTex) => {
    baseTex.colorSpace = THREE.SRGBColorSpace;
    baseTex.wrapS = THREE.ClampToEdgeWrapping;
    baseTex.wrapT = THREE.ClampToEdgeWrapping;
    baseTex.flipY = true;

    if (pending.mode === 'single' && pending.wall) {
      const tex = baseTex.clone(); tex.needsUpdate = true;
      pending.wall.material = new THREE.MeshBasicMaterial({
        map: tex, side: THREE.DoubleSide, color: 0xffffff
      });
      pending.wall.renderOrder = 0;
    }

    if (pending.mode === 'ellipse' && pending.oneGroup) {
      const oneGroup = pending.oneGroup;
      const wallsGroup = oneGroup.getObjectByName('wallsGroup');
      if (!wallsGroup) { pending = null; return; }

      // 이전 래핑 제거
      const prev = oneGroup.getObjectByName('wrapGroup');
      if (prev) {
        disposeObject(prev);
        oneGroup.remove(prev);
      }
      const wrapGroup = new THREE.Group();
      wrapGroup.name = 'wrapGroup';
      wrapGroup.renderOrder = 10; // ★ 벽 위에 얹기
      oneGroup.add(wrapGroup);

      const ellipseObj = oneGroup.userData.polyObj;     // {type:'ellipse', points:[...], __ellipseMeta?}
      const ellipsePts = ellipseObj.points;

      const blockerPolys = (window.loadedPolyObjs || [])
        .filter(o => o !== ellipseObj && o.points?.length >= 3)
        .map(o => o.points);

      // 원/타원 둘레 중, 다른 폴리곤 내부에 겹치는 구간 = blocked
      const blocked = computeBlockedURanges(ellipsePts, blockerPolys);
      const allowed = complementRanges(blocked);

      const walls = wallsGroup.children
        .filter(m => m.name === 'wall' && m.userData)
        .sort((a,b)=> (a.userData.order ?? 0) - (b.userData.order ?? 0));

      for (const w of walls) {
        const { u0, u1, p0, p1, height, angle } = w.userData;
        const spans = intersectSpanWithRanges([u0, u1], allowed);
        if (!spans.length) continue;

        for (const [s, e] of spans) {
          const f0 = (s - u0) / (u1 - u0);
          const f1 = (e - u0) / (u1 - u0);

          const q0 = { x: p0.x + (p1.x - p0.x) * f0, z: p0.z + (p1.z - p0.z) * f0 };
          const q1 = { x: p0.x + (p1.x - p0.x) * f1, z: p1 ? (p0.z + (p1.z - p0.z) * f1) : p0.z };
          const pieceLen = Math.hypot(q1.x - q0.x, q1.z - q0.z);
          if (pieceLen < 1e-4) continue;

          const midX = (q0.x + q1.x) * 0.5;
          const midZ = (q0.z + q1.z) * 0.5;

          const geo = new THREE.PlaneGeometry(pieceLen, height);
          // ★ 한 장 이미지를 둘레 0..1에 맵: offset=s, repeat=(e-s)
          const tex = baseTex.clone(); tex.needsUpdate = true;
          tex.offset.set(s, 0);
          tex.repeat.set(e - s, 1);

          const mat = new THREE.MeshBasicMaterial({
            map: tex,
            side: THREE.DoubleSide,
            color: 0xffffff,
            polygonOffset: true,
            polygonOffsetFactor: -2,
            polygonOffsetUnits: -2,
            depthTest: true,
            depthWrite: true,
            transparent: true
          });

          const slice = new THREE.Mesh(geo, mat);
          slice.position.set(midX, height / 2, midZ);
          slice.rotation.set(0, angle, 0);
          slice.renderOrder = 10; // ★ 벽보다 항상 위로
          wrapGroup.add(slice);
        }
      }
    }

    pending = null;
  });
});

// ───────────────────────────────────────────────────────────
// 리사이즈 + 재프레이밍
// ───────────────────────────────────────────────────────────
function onResize() {
  const w = container.clientWidth;
  const h = container.clientHeight;
  renderer.setSize(w, h);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  autoFrame(buildingGroup, { fitOffset: 1.25 });
}
window.addEventListener('resize', onResize);
if ('ResizeObserver' in window) new ResizeObserver(onResize).observe(container);

// ───────────────────────────────────────────────────────────
renderer.setAnimationLoop(() => {
  controls.update();
  renderer.render(scene, camera);
});

updateBuildingBox();
drawBoundaryLines();

